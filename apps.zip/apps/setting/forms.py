from django import forms

from .models import AttendenceSetting


class AttendanceSettingForm(forms.ModelForm):
    class Meta:
        model = AttendenceSetting
        fields = ['website_name', 'send_id_token']
        widgets = {
            'website_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter your institute name here...'
            }),
            'send_id_token': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter your unique ID token here...'
            }),
        }
        labels = {
            'website_name': 'Sender ID',
            'send_id_token': 'Token'
        }
