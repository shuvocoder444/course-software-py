from datetime import datetime

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView, View, DetailView
from django.http import JsonResponse

from apps.account.views import AdminRoleRequiredMixin, VuxyVerticalLayoutMixin
from apps.courses.models import Batch  # আপনার অ্যাপ স্ট্রাকচার অনুযায়ী পাথ

from .forms import StudentForm
from .models import Student

# কাস্টম ইউজার মডেল একটি ভেরিয়েবলে নেওয়া হলো
User = get_user_model()


# ==============================================================================
#  ১. STUDENT LIST VIEW (With Live Filters & Pagination)
# ==============================================================================
class StudentListView(LoginRequiredMixin, AdminRoleRequiredMixin, VuxyVerticalLayoutMixin, ListView):
    model = Student
    context_object_name = 'students'
    template_name = 'student.html'
    ordering = ['-id']
    paginate_by = 10  # প্রতি পেজে ১০টি রেকর্ড দেখাবে

    def get_queryset(self):
        queryset = super().get_queryset()

        # ফ্রন্টএন্ড ফিল্টার থেকে ডেটা নেওয়া
        search_query = self.request.GET.get('search', '')
        course_filter = self.request.GET.get('course', '')
        batch_filter = self.request.GET.get('batch', '')

        if search_query:
            queryset = queryset.filter(name__icontains=search_query) | queryset.filter(student_id__icontains=search_query) | queryset.filter(phone__icontains=search_query)

        if course_filter:
            queryset = queryset.filter(course_id=course_filter)

        if batch_filter:
            queryset = queryset.filter(batch_id=batch_filter)

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from apps.courses.models import Course
        context['courses'] = Course.objects.all()
        context['batches'] = Batch.objects.all()
        return context


# ==============================================================================
#  ২. STUDENT PRINT VIEW
# ==============================================================================
class StudentPrintView(LoginRequiredMixin, AdminRoleRequiredMixin, DetailView):
    model = Student
    template_name = 'print.html'
    context_object_name = 'student'


# ==============================================================================
#  ৩. STUDENT APPROVE VIEW
# ==============================================================================
class StudentApproveView(LoginRequiredMixin, AdminRoleRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        student = get_object_or_404(Student, pk=pk)
        student.status = 'approved'
        student.save()
        messages.success(request, f"{student.name}-এর অ্যাডমিশন অ্যাপ্রুভ করা হয়েছে।")
        return redirect('student_list')


# ==============================================================================
#  ৪. CREATE STUDENT VIEW (Username & Password = Phone Number)
# ==============================================================================
class StudentCreateView(LoginRequiredMixin, AdminRoleRequiredMixin, VuxyVerticalLayoutMixin, CreateView):
    model = Student
    form_class = StudentForm
    template_name = 'student_form.html'
    success_url = reverse_lazy('student_list')

    def form_valid(self, form):
        # ১. ফর্মের ডেটা মেমরিতে হোল্ড করা
        student = form.save(commit=False)

        # ২. অটোমেটিক সেশন সেট করা
        current_year = datetime.now().year
        next_year = current_year + 1
        student.session = f"{current_year}-{next_year}"

        # ৩. স্ট্যাটাস নিশ্চিত করা
        student.status = 'pending'

        # ৪. স্বয়ংক্রিয়ভাবে ইউজার অ্যাকাউন্ট তৈরি এবং লিঙ্ক করার লজিক
        student_phone = form.cleaned_data.get('phone')
        student_email = form.cleaned_data.get('email')
        student_name = form.cleaned_data.get('name')

        if student_phone:
            # আগে থেকে এই ফোন নাম্বার দিয়ে কোনো অ্যাকাউন্ট আছে কিনা চেক করা হচ্ছে
            user_instance = User.objects.filter(username=student_phone).first()

            if not user_instance:
                # নতুন ইউজার তৈরি (ইউজারনেম এবং পাসওয়ার্ড দুটোই ফোন নাম্বার)
                user_instance = User.objects.create_user(
                    username=student_phone,
                    password=student_phone,
                    email=student_email if student_email else '',
                    first_name=student_name
                )
            else:
                messages.warning(self.request, f"এই ফোন নাম্বার ({student_phone}) দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট তৈরি করা আছে! সেটিই এই স্টুডেন্টের সাথে লিঙ্ক করা হলো।")

            # 👑 ফিক্সড লজিক: তৈরি হওয়া বা আগের ইউজার অ্যাকাউন্টটি স্টুডেন্টের ওয়ান-টু-ওয়ান ফিল্ডে লিঙ্ক করা হলো
            student.account = user_instance
        else:
            messages.error(self.request, "স্টুডেন্টের মোবাইল নাম্বার পাওয়া যায়নি! অ্যাকাউন্ট তৈরি করা সম্ভব হয়নি।")
            return self.form_invalid(form)

        # ৫. ডেটাবেজে ফাইনাল স্টুডেন্ট সেভ
        student.save()

        messages.success(self.request, f"Student {student.name} created successfully! ID: {student.student_id}. User account created with Phone Number.")
        return redirect(self.success_url)


# ==============================================================================
#  ৫. EDIT / UPDATE STUDENT VIEW
# ==============================================================================
class StudentEditView(LoginRequiredMixin, AdminRoleRequiredMixin, VuxyVerticalLayoutMixin, UpdateView):
    model = Student
    form_class = StudentForm
    template_name = 'student_form.html'
    success_url = reverse_lazy('student_list')

    def form_valid(self, form):
        messages.success(self.request, "Student profile updated successfully!")
        return super().form_valid(form)


# ==============================================================================
#  ৬. DELETE STUDENT VIEW
# ==============================================================================
class StudentDeleteView(LoginRequiredMixin, AdminRoleRequiredMixin, View):
    def post(self, request, pk):
        student_instance = get_object_or_404(Student, pk=pk)
        student_name = student_instance.name
        student_instance.delete()
        messages.success(request, f"Student '{student_name}' record deleted successfully!")
        return redirect('student_list')

    def get(self, request, pk):
        return self.post(request, pk)


# ==============================================================================
#  ৭. AJAX API VIEW (কোর্সের আইডি অনুযায়ী ব্যাচ লোড করার জন্য)
# ==============================================================================
class LoadBatchesView(View):
    def get(self, request):
        course_id = request.GET.get('course_id')
        # কোর্স আইডি অনুযায়ী ফিল্টার করে শুধু id এবং batch_number পাঠানো হচ্ছে
        batches = Batch.objects.filter(course_id=course_id).values('id', 'batch_number')
        return JsonResponse(list(batches), safe=False)
